Area sometimes recorded as mm2, sometimes cm2. Do not scale without review. Replacement glyph: �
